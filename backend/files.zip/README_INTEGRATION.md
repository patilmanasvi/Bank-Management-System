# Integration Guide

This covers all 6 of your backend tasks. Here's where each file goes and what it does.

## 1. Replace existing files

Copy these into your local clone, overwriting the originals at the same path:

| File | Goes to | What changed |
|---|---|---|
| `AccountService.java` | `backend/src/main/java/com/bank/service/` | Fixed: web API deposit/withdraw now write to the `transaction` table (previously only the Swing UI did). Added status checks so frozen/closed accounts can't transact. Added `openAccount()`, `setAccountStatus()`, `listAllAccountsJson()`. |
| `TransactionService.java` | `backend/src/main/java/com/bank/service/` | Added filter support to `getHistory()`. Fixed transfer so a frozen/closed **sending** account is blocked (previously only the receiving account was checked). |
| `BankWebServer.java` | `backend/src/main/java/com/bank/ui/` | Fixed: amount-parsing crash on bad input now returns clean JSON 400 instead of a raw 500. Added 7 new endpoints (below). Transaction history now supports filters. |

## 2. Add new files

| File | Goes to |
|---|---|
| `LoanService.java` | `backend/src/main/java/com/bank/service/` |
| `SystemTest.java` | Anywhere outside `src/` — e.g. project root or a `tests/` folder. It's a standalone file with no package declaration, run separately from the main app. |

## 3. Run the schema update once

`schema_updates.sql` adds `'FROZEN'` as a valid account status (needed for the freeze/activate feature). Run it once against your existing database:

```
mysql -u root -p bank_db < schema_updates.sql
```

(or paste its contents into your MySQL client / Workbench)

## 4. New API endpoints added

| Endpoint | Method | Purpose |
|---|---|---|
| `/api/account/open` | POST | Open Savings/Current/Fixed Deposit account for an existing customer |
| `/api/admin/accounts` | GET | List all accounts with balances and status |
| `/api/admin/account/freeze` | POST | Freeze an account |
| `/api/admin/account/activate` | POST | Reactivate a frozen account |
| `/api/loan/apply` | POST | Customer applies for a loan |
| `/api/loan/list` | GET | List loans, optional `?status=PENDING` |
| `/api/loan/decision` | POST | Employee/Admin approves or rejects a loan |
| `/api/transactions/history` | GET | Now also accepts `?type=DEPOSIT&from=2026-01-01&to=2026-09-01` |

### Example request bodies

```
POST /api/account/open
{"customerId": 1001, "branchId": 1, "accountType": "CURRENT", "initialDeposit": "6000.00"}

POST /api/admin/account/freeze
{"accountNumber": "ACC100101"}

POST /api/loan/apply
{"customerId": 1001, "loanTypeId": 2, "branchId": 1, "amount": "150000.00", "tenureMonths": 36}

POST /api/loan/decision
{"loanId": 303, "decision": "APPROVED", "empId": 102}
```

## 5. Running the test suite (End-to-end + API Testing tasks)

1. Start the server as usual (`run.bat` / `start_website.bat`, or run `BankWebServer.main()`)
2. In a separate terminal:
   ```
   javac SystemTest.java
   java SystemTest
   ```
3. It prints `[PASS]`/`[FAIL]` for each check and a summary count. Requires Java 11+ (uses `java.net.http.HttpClient`).

It tests against the seeded accounts `ACC100101` and `ACC100401` from your sample data, so run it against a dev database you don't mind modifying (it deposits/withdraws/transfers real amounts).

## 6. What I deliberately did NOT touch

- `DBConnection.java` (hardcoded credentials) — you said that's not your part
- `CurrentAccount.java`'s overdraft bug (the OOP model layer) — belongs to whoever owns the model classes; worth mentioning to them, but I left the model files alone
- The frontend (`frontend/` folder, `login.html` etc.) — none of your 6 tasks are frontend work, but note the new endpoints above will need frontend forms/buttons to actually be reachable by users (the admin panel, loan pages, and open-account flow don't have UI yet — only the API side)

## 7. Still needs your judgment

- **Admin/Employee endpoint security**: none of the new admin/loan endpoints check *who's* calling them (matching the existing project's simple auth style — no sessions/tokens anywhere yet). Anyone who knows the URL can freeze an account or approve a loan. Worth raising with your team whether that's in scope to fix, or acceptable for this project's level.
- **Git workflow**: create a branch (e.g. `yourname-backend`), add these files, commit, push, and open a PR — see the earlier steps in this conversation.
